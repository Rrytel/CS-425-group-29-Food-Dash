namespace Server.Services;

public interface IPlayerService
{
    void DoSomething();
}
public abstract class PlayerService : IPlayerService
{
    public void DoSomething() {
        Console.WriteLine("hey!");
    }

    void IPlayerService.DoSomething()
    {
        throw new NotImplementedException();
    }
}

public class MockPlayerService : IPlayerService {
    public void DoSomething()
    {
        Console.WriteLine("hey! from the mock service!");
    }  
}