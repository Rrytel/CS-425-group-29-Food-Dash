﻿namespace SharedLibrary;

public abstract class Player
{
    public abstract int Id { set; }

    public int Level { get; set; }
}